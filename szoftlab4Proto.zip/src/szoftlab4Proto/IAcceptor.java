package szoftlab4Proto;

public interface IAcceptor {
	
	public void accept(IColliding colliding);

}
